<?php
/**
 * Plugin Name:       HPP Portfolio
 * Plugin URI:        https://hyperplanestudio.com
 * Description:       Custom Portfolio Post Type pluin for Hyperplane Studio themes
 * Version:           1.0.0
 * Author:            Rick Alday
 * Author URI:        https://hyperplanestudio.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       hpp-portfolio
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! class_exists( 'HPP_Portfolio' ) ) {

	class HPP_Portfolio {

		public function __construct() {
			$this->constants();
			$this->includes();
		}

		/**
		 * Constants
		 */
		private function constants() {

			// Plugin Folder URL.
			if ( ! defined( 'HPP_PORTFOLIO_PLUGIN_URL' ) ) {
				define( 'HPP_PORTFOLIO_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
			}

			// Plugin Folder Path.
			if ( ! defined( 'HPP_PORTFOLIO_PLUGIN_PATH' ) ) {
				define( 'HPP_PORTFOLIO_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
			}
		}

		/**
		 * Includes
		 */
		private function includes() {

			// functions
			require_once HPP_PORTFOLIO_PLUGIN_PATH . 'includes/hpp-portfolio-post-type.php';
			require_once HPP_PORTFOLIO_PLUGIN_PATH . 'includes/hpp-portfolio-helpers.php';
			require_once HPP_PORTFOLIO_PLUGIN_PATH . 'includes/hpp-portfolio-order.php';
		}
		
	}
}
$hpp_portfolio = new HPP_Portfolio;