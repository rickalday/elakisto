<?php

class hpp_portfolio_order_engine {

	function __construct() {

		add_action( 'admin_init', array( $this, 'hppport_portfolio_refresh' ) );
		add_action( 'admin_init', array( $this, 'hppport_portfolio_load_scripts' ) );
		add_action( 'wp_ajax_update-menu-order', array( $this, 'hppport_portfolio_update_order' ) );
		add_action( 'pre_get_posts', array( $this, 'hppport_portfolio_pre_get_posts' ) );

	}

	function hppport_portfolio_check_scripts() {

		if ( strstr( $_SERVER['REQUEST_URI'], 'wp-admin/edit.php' ) && isset( $_GET['post_type'] ) && $_GET['post_type'] == 'portfolio' ) {
			return true;
		}

	}

	function hppport_portfolio_check_post_scripts() {

		if ( ( strstr( $_SERVER['REQUEST_URI'], 'wp-admin/post-new.php' ) && isset( $_GET['post_type'] ) && $_GET['post_type'] == 'portfolio' ) || ( strstr( $_SERVER['REQUEST_URI'], 'wp-admin/post.php' ) && strstr( $_SERVER['REQUEST_URI'], 'action=edit') ) ) {
			return true;
		}

	}

	function hppport_portfolio_load_scripts() {

		if ( $this->hppport_portfolio_check_scripts() ) {
			wp_enqueue_script( 'jquery-ui-sortable' );
			wp_enqueue_script( 'hppport-portfolio-order-js', plugin_dir_url( __FILE__ ) . 'assets/js/portfolio-order.js', array( 'jquery' ), null, true );
			wp_enqueue_style( 'hppport-portfolio-order', plugin_dir_url( __FILE__ ) . 'assets/css/portfolio-order.css', array(), null, 'all' );
		}

		if ( $this->hppport_portfolio_check_post_scripts() ) {
			wp_enqueue_style( 'hppport-portfolio-fields-metabox', plugin_dir_url(__FILE__) . 'assets/css/fields-metabox.css', array(), null, 'all' );
			wp_enqueue_style( 'hppport-portfolio-gallery-metabox', plugin_dir_url(__FILE__) . 'assets/css/gallery-metabox.css', array(), null, 'all' );
			wp_enqueue_script( 'hppport-portfolio-gallery-metabox-js', plugin_dir_url(__FILE__) . 'assets/js/gallery-metabox.js', array( 'jquery' ), null, true );
		}

	}

	function hppport_portfolio_refresh() {

		global $wpdb;

		$result = $wpdb->get_results("
		SELECT count(*) as cnt, max(menu_order) as max, min(menu_order) as min
		FROM $wpdb->posts
		WHERE post_type = 'portfolio' AND post_status IN ('publish', 'pending', 'draft', 'private', 'future')
		");

		$results = $wpdb->get_results("
		SELECT ID
		FROM $wpdb->posts
		WHERE post_type = 'portfolio' AND post_status IN ('publish', 'pending', 'draft', 'private', 'future')
		ORDER BY menu_order ASC
		");

		foreach ( $results as $key => $result ) {
			$wpdb->update( $wpdb->posts, array( 'menu_order' => $key + 1 ), array( 'ID' => $result->ID ) );
		}

	}

	function hppport_portfolio_update_order() {

		global $wpdb;
		parse_str( $_POST['order'], $data );

		if ( !is_array( $data ) )
		return false;

		$id_arr = array();
		foreach ( $data as $key => $values ) {
			foreach ( $values as $position => $id ) {
				$id_arr[] = $id;
			}
		}

		$menu_order_arr = array();
		foreach ( $id_arr as $key => $id ) {
			$results = $wpdb->get_results( "SELECT menu_order FROM $wpdb->posts WHERE ID = " . intval( $id ) );
			foreach ( $results as $result ) {
				$menu_order_arr[] = $result->menu_order;
			}
		}

		sort( $menu_order_arr );

		foreach ( $data as $key => $values ) {
			foreach ( $values as $position => $id ) {
				$wpdb->update( $wpdb->posts, array( 'menu_order' => $menu_order_arr[$position] ), array( 'ID' => intval( $id ) ) );
			}
		}

	}

	function hppport_portfolio_pre_get_posts( $wp_query ) {

		$objects = array( 'portfolio' );

		if ( isset( $wp_query->query['post_type'] ) && !isset( $_GET['orderby'] ) ) {
			if ( in_array( $wp_query->query['post_type'], $objects ) ) {
				$wp_query->set( 'orderby', 'menu_order' );
				$wp_query->set( 'order', 'ASC' );
			}
		}

	}

}

$hppport_portfolio_order_engine = new hpp_portfolio_order_engine();

?>
