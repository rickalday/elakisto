<?php
/**
 * HPP Portfolio Helper Functions
 */

/* Add Meta Boxes */
function hppport_add_metabox() {

	add_meta_box( 'hppport-gallery-metabox', esc_html__( 'Portfolio Images', 'hpp-portfolio' ), 'hppport_gallery_markup', 'portfolio', 'normal', 'high' );

}
add_action( 'add_meta_boxes', 'hppport_add_metabox' );
/* */

/**
 * Add Video URL field
 */
add_filter( 'attachment_fields_to_edit', 'videoURL_attachment_fields', 10, 2 );
function videoURL_attachment_fields( $fields, $post ) {
    $meta = get_post_meta( $post->ID, 'video_url', true );
    $fields['video_url'] = array(
            'label' =>  __( 'Video URL', 'hpp-portfolio' ),
            'input' => 'text',
            'value' => $meta,
            'show_in_edit' => true,
    );

    return $fields;         
}

/**
 * Update custom field within media overlay (via ajax)
 */
add_action( 'wp_ajax_save-attachment-compat', 'videoURL_media_fields', 0, 1 );
function videoURL_media_fields() {
    $post_id = $_POST['id'];
    $meta = $_POST['attachments'][ $post_id ]['video_url'];
    update_post_meta( $post_id , 'video_url', $meta );

    clean_post_cache( $post_id );
}

/**
 * Update media custom field from edit media page (non ajax).
 */
add_action( 'edit_attachment', 'videoURL_update_attachment_meta', 1 );
function videoURL_update_attachment_meta( $post_id ) {
    $video_url = isset( $_POST['attachments'][ $post_id ]['video_url'] ) ? $_POST['attachments'][ $post_id ]['video_url'] : false;
    update_post_meta( $post_id, 'video_url', $video_url );
    return;
}

/* Meta Box Markups */
function hppport_gallery_markup( $post ) {

	$ids = get_post_meta( $post->ID, 'hppport_gallery_id', true ); ?>

	<table class="hppport-form-table">
		<tr>
			<td>
				<a class="hppport-button-gallery-add button-primary" href="#" data-uploader-title="<?php echo esc_attr__( 'Add Image(s) to Portfolio', 'hpp-portfolio' ); ?>" data-uploader-button-text="<?php echo esc_attr__( 'Add Image(s)', 'hpp-portfolio' ); ?>" data-js-term-change-image="<?php echo esc_attr__( 'Change Image', 'hpp-portfolio' ); ?>" data-js-term-change="<?php echo esc_attr__( 'Change', 'hpp-portfolio' ); ?>" data-js-term-remove="<?php echo esc_attr__( 'Remove', 'hpp-portfolio' ); ?>" data-js-term-caption="<?php echo esc_attr__( 'Caption', 'hpp-portfolio' ); ?>"><?php echo esc_html__( 'Add Image(s)', 'hpp-portfolio' ); ?></a><a class="hppport-button-remove-all button" href="#"><?php echo esc_html__( 'Remove All', 'hpp-portfolio' ); ?></a>
				<ul id="hppport-gallery-metabox-list">
					<?php if ( $ids ) {
						foreach ( $ids as $key => $value ) {
							$image = wp_get_attachment_image_src( $value );
							$image_id = get_post( $value );
							$image_caption = $image_id->post_excerpt;
							$video_url = get_post_meta( $value, 'video_url', true );
							//echo $video_url;
							?>
							<li>
								<input class="hppport-image-val" type="hidden" name="hppport_gallery_id[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>">
								<img class="hppport-image-preview" src="<?php echo esc_attr( $image[0] ); ?>">
								<a class="hppport-button-change-image button button-small" href="#" data-uploader-title="<?php echo esc_attr__( 'Change Image', 'hpp-portfolio' ); ?>" data-uploader-button-text="<?php echo esc_attr__( 'Change Image', 'hpp-portfolio' ); ?>"><?php echo esc_html__( 'Change', 'hpp-portfolio' ); ?></a><a class="hppport-button-remove-image button button-small" href="#"><?php echo esc_html__( 'Remove', 'hpp-portfolio' ); ?></a>
								<input type="text" name="hppport_caption_id[<?php echo esc_attr( $key ); ?>]" class="widefat hppport-image-caption" placeholder="<?php echo esc_attr__( 'Caption', 'hpp-portfolio' ); ?>" value="<?php echo esc_attr( $image_caption ); ?>" disabled>
								<input type="text" name="hppport_video_url[<?php echo esc_attr( $video_url ); ?>]" class="widefat hppport-video-url" placeholder="<?php echo esc_attr__( 'Video URL', 'hpp-portfolio' ); ?>" value="<?php echo esc_attr( $video_url ); ?>" disabled>

							</li>
							<?php
						}
					}	?>
				</ul>
			</td>
		</tr>
	</table>

<?php }



/* Save Meta Boxes */
function hppport_portfolio_save_metabox( $post_id ) {

	if ( !current_user_can( 'edit_post', $post_id ) ) { return $post_id; }
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return $post_id; }

	if ( isset( $_POST['hppport_gallery_id'] ) ) {
		update_post_meta( $post_id, 'hppport_gallery_id', $_POST['hppport_gallery_id'] );
	} else {
		delete_post_meta( $post_id, 'hppport_gallery_id' );
	}

}
add_action( 'save_post', 'hppport_portfolio_save_metabox' );
/* */


function hppport_portfolio_table( $columns ) {

	$new_columns = array(
		'cb' => '<input type=\"checkbox\" />',
		'hppport_featured_image' => esc_html__( 'Portfolio', 'hpp-portfolio' ),
		'title' => esc_html__( 'Title', 'hpp-portfolio' ),
		'hppport_categories' => esc_html__( 'Categories', 'hpp-portfolio' ),
	);

	return $new_columns;

}
add_filter( 'manage_portfolio_posts_columns' , 'hppport_portfolio_table' );

function hppport_portfolio_table_columns( $column, $post_id ) {

	switch ( $column ) {

		case 'hppport_featured_image':
		//$ids = get_post_meta( $post_id, 'hppport_gallery_id', true );
		if ( has_post_thumbnail( $post_id ) ) {
			$image_array = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), 'thumbnail' );
			$final_image_path = $image_array[0];
		} else {
			$final_image_path = plugin_dir_url( __FILE__ ) . 'images/no-thumbnail.png';
		}
		echo '<a class="hppport-featured-image" href="post.php?post=' . $post_id . '&action=edit"><img src="' . $final_image_path . '" /></a>';
		break;

		case 'hppport_categories':
		$terms = get_the_terms( $post_id, 'portfolio_category' );
		if ( is_array( $terms ) ) {
			foreach( $terms as $key => $term ) {
				$terms[$key] = '<a href="edit.php?post_type=portfolio&portfolio_category=' . $term->slug . '">' . $term->name . '</a>';
			}
			echo implode( ', ', $terms );
		}
		break;


	}

}
add_action( 'manage_portfolio_posts_custom_column', 'hppport_portfolio_table_columns', 10, 2 );


/* Portfolio Gallery */
function hppport_portfolio_gallery( $id ) {
	$html = '';
	$attachment_ids = get_post_meta( $id, 'hppport_gallery_id', true );
	$container_class = apply_filters( 'portfolio_grid_item_container_class', 'small-thumbs' );
	$title = get_the_title( $id );
	$post_permalink = get_permalink( $id );
	$html .= '<div id="portfolio-gallery-' . esc_attr( $id ) . '" class="' . esc_attr( $container_class ) . '">';
	$html .= '<div class="header"><h2><a href="' . esc_attr( $post_permalink ) . '" data-title="' . esc_attr( $title ) . '"><span>' . esc_attr( $title ) . '</span></a></h2></div>';
	if ( $attachment_ids ) {
		foreach ( $attachment_ids as $attachment_id ) {
			$index = 0;
			$image = wp_get_attachment_image_src( $attachment_id, 'medium' );
			$image_caption = wp_get_attachment_caption( $attachment_id );
			$video_url = get_post_meta( $attachment_id, 'video_url', true );
			$thumb_class = empty($video_url) ? 'small-thumb' : 'video-thumb';
			$html .= '<a id="thumb-' . esc_attr( $id ) . '-' . esc_attr( $attachment_id ) . '" data-id="' . esc_attr( $id ) . '-' . esc_attr( $attachment_id ) . '" data-index="' . esc_attr( $index ) . '" class="thumb ' . esc_attr( $thumb_class ) . '" href="' . esc_attr( $post_permalink ) . '" data-title="' . esc_attr( $title ) . '" aria-label="' . esc_attr( $title ) . '">';
			$html .= '<div class="img-holder no-bg">';
			$html .= '<img alt="' . esc_attr( $image_caption) . '" src="' . esc_attr( $image[0] ) . '">';
			$html .= '<canvas width="' . esc_attr( $image[1] ) . '" height="' . esc_attr( $image[2] ) . '"></canvas>';
			$html .= '</div>';
			$html .= '</a>';
			$index++;			
		}
	}
	$html .= '</div>';
	return $html;
}