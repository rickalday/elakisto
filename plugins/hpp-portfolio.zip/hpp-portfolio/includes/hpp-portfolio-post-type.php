<?php

/**
 * HPP Portfolio Post Type
 *
 *
 * @package   hpp-portfolio/includes/hpp-portfolio-post-type.php
 * @author    Rick Alday
 * @license   GPL-2.0+
 * @link      https://hyperplanestudio.com
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/* Portfolio Post Type */
function hppport_create_portfolio_post_type() {

	$labels = array(
		'all_items' => esc_html__( 'All Items', 'hpp-portfolio' ),
		'edit_item' => esc_html__( 'Edit Portfolio Item', 'hpp-portfolio' ),
		'add_new' => esc_html__( 'Add New Portfolio', 'hpp-portfolio' ),
		'add_new_item' => esc_html__( 'Add New Portfolio Item', 'hpp-portfolio' ),
		'not_found' => esc_html__( 'No Portfolio items found.', 'hpp-portfolio' ),
		'not_found_in_trash' => esc_html__( 'No Portfolio items found in Trash.', 'hpp-portfolio' ),
	);

	$args = array(
		'labels' => $labels,
		'public' => true,
		'show_ui' => true,
		'has_archive' => true,
		'menu_icon' => 'dashicons-images-alt',
		'capability_type' => 'post',
		'label' => esc_html__( 'HPP Portfolio', 'hpp-portfolio' ),
		'supports' => array( 'title', 'thumbnail', 'editor' ),
		'rewrite' => array( 'slug' => 'portfolio' ),
	);

	register_post_type( 'portfolio', $args );

}
add_action( 'init', 'hppport_create_portfolio_post_type' );
/* */

/* Portfolio Category Taxonomy */
function hppport_create_portfolio_category_tax() {

	$labels = array(
		'name' => esc_html__( 'Portfolio Categories', 'hpp-portfolio' ),
		'singular_name' => esc_html__( 'Portfolio Category', 'hpp-portfolio' ),
		'menu_name' => esc_html__( 'Categories', 'hpp-portfolio' ),
		'all_items' => esc_html__( 'All Categories', 'hpp-portfolio' ),
		'parent_item' => esc_html__( 'Parent Category', 'hpp-portfolio' ),
		'parent_item_colon' => esc_html__( 'Parent Category:', 'hpp-portfolio' ),
		'new_item_name' => esc_html__( 'New Category Name', 'hpp-portfolio' ),
		'add_new_item' => esc_html__( 'Add New Category', 'hpp-portfolio' ),
		'edit_item' => esc_html__( 'Edit Category', 'hpp-portfolio' ),
		'update_item' => esc_html__( 'Update Category', 'hpp-portfolio' ),
		'separate_items_with_commas' => esc_html__( 'Separate categories with commas', 'hpp-portfolio' ),
		'search_items' => esc_html__( 'Search Portfolio Categories', 'hpp-portfolio' ),
		'add_or_remove_items' => esc_html__( 'Add or remove categories', 'hpp-portfolio' ),
		'choose_from_most_used' => esc_html__( 'Choose from the most used categories', 'hpp-portfolio' ),
		'not_found' => esc_html__( 'No categories found.', 'hpp-portfolio' ),
	);

	register_taxonomy( 'portfolio_category', 'portfolio', array(
		'labels' => $labels,
		'hierarchical' => true,
		'public' => true,
		'show_admin_column' => true,
		'rewrite' => array( 'slug' => 'portfolio-category' ),
	)
);

}
add_action( 'init', 'hppport_create_portfolio_category_tax' );
