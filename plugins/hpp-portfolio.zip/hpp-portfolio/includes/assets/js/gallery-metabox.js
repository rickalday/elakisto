jQuery( document ).ready( function( $ ) {

  "use strict";

  /* START */

  var file_frame, attachment, selection, listIndex, term_change_image, term_change, term_remove, term_caption, index, currently_selected, that;
  var currently_added = [];

  // Add
  $( '#hppport-gallery-metabox' ).on( 'click', 'a.hppport-button-gallery-add', function( e ) {

    e.preventDefault();
    hppport_setFileFrame( $( this ), 'add' );

    file_frame.on( 'open', function() {

      selection = file_frame.state().get( 'selection' );
      currently_selected = [];

      $( '.hppport-image-val' ).each( function() {
        attachment = wp.media.attachment( $( this ).val() );
        selection.add( attachment ? [ attachment ] : [] );
        currently_selected.push( $( this ).val() );
      } );

      currently_added = currently_selected;

    } );

    file_frame.on( 'select', function() {

      listIndex = $( '#hppport-gallery-metabox-list li' ).index( $( '#hppport-gallery-metabox-list li:last' ) ),
      selection = file_frame.state().get( 'selection' );
      term_change_image = $( '.hppport-button-gallery-add' ).attr( 'data-js-term-change-image' );
      term_change = $( '.hppport-button-gallery-add' ).attr( 'data-js-term-change' );
      term_remove = $( '.hppport-button-gallery-add' ).attr( 'data-js-term-remove' );
      term_caption = $( '.hppport-button-gallery-add' ).attr( 'data-js-term-caption' );

      selection.map( function( attachment, i ) {

        attachment = attachment.toJSON(),
        index = listIndex + ( i + 1 );

        if ( currently_added.length == 0 ) {

          $( '#hppport-gallery-metabox-list' ).append( '<li><input class="hppport-image-val" type="hidden" name="hppport_gallery_id[' + index + ']" value="' + attachment.id + '"><img class="hppport-image-preview" src="' + attachment.sizes.thumbnail.url + '"><a class="hppport-button-change-image button button-small" href="#" data-uploader-title="' + term_change_image + '" data-uploader-button-text="' + term_change_image + '">' + term_change + '</a><a class="hppport-button-remove-image button button-small" href="#">' + term_remove + '</a><input type="text" name="hppport_caption_id[' + index + ']" class="widefat hppport-image-caption" placeholder="' + term_caption + '" value="' + attachment.caption + '" disabled></li>' );

          currently_added.push( attachment.id );

        } else {

          if ( currently_added.indexOf( String( attachment.id ) ) == '-1' ) {

            $( '#hppport-gallery-metabox-list' ).append( '<li><input class="hppport-image-val" type="hidden" name="hppport_gallery_id[' + index + ']" value="' + attachment.id + '"><img class="hppport-image-preview" src="' + attachment.sizes.thumbnail.url + '"><a class="hppport-button-change-image button button-small" href="#" data-uploader-title="' + term_change_image + '" data-uploader-button-text="' + term_change_image + '">' + term_change + '</a><a class="hppport-button-remove-image button button-small" href="#">' + term_remove + '</a><input type="text" name="hppport_caption_id[' + index + ']" class="widefat hppport-image-caption" placeholder="' + term_caption + '" value="' + attachment.caption + '" disabled></li>' );

            currently_added.push( attachment.id );

          }

        }

      } );

      hppport_resetIndex();
      hppport_checkRemoveAll();

    } );

    hppport_makeSortable();
    file_frame.open();

  } );

  // Change
  $( '#hppport-gallery-metabox' ).on( 'click', 'a.hppport-button-change-image', function( e ) {

    e.preventDefault();
    that = $( this );
    hppport_setFileFrame( $( this ), false );

    file_frame.on( 'open', function() {

      selection = file_frame.state().get( 'selection' );
      attachment = wp.media.attachment( that.parent().find( 'input:hidden' ).val() );
      selection.add( attachment ? [ attachment ] : [] );

    } );

    file_frame.on( 'select', function() {

      attachment = file_frame.state().get( 'selection' ).first().toJSON();
      that.parent().find( 'input:hidden' ).attr( 'value', attachment.id );
      that.parent().find( 'img.hppport-image-preview' ).attr( 'src', attachment.sizes.thumbnail.url );
      that.parent().find( 'input.hppport-image-caption' ).val( attachment.caption );

    } );

    file_frame.open();

  } );

  // Remove
  $( '#hppport-gallery-metabox' ).on( 'click', 'a.hppport-button-remove-image', function( e ) {

    e.preventDefault();
    index = currently_added.indexOf( $( this ).parent().find( '.hppport-image-val' ).val() );

    if ( index > -1 ) {
      currently_added.splice( index, 1 );
    }

    $( this ).parents( 'li' ).remove();
    hppport_resetIndex();
    hppport_checkRemoveAll();

  } );

  // Remove All
  $( '#hppport-gallery-metabox' ).on( 'click', 'a.hppport-button-remove-all', function( e ) {

    e.preventDefault();
    $( '#hppport-gallery-metabox-list li' ).remove();
    currently_added = [];
    hppport_resetIndex();
    hppport_checkRemoveAll();

  } );

  // Functions
  function hppport_setFileFrame( obj, mul ) {

		if ( file_frame ) {
			file_frame.close();
		}

		file_frame = wp.media.frames.file_frame = wp.media( {
			title: obj.data( 'uploader-title' ),
			button: {
				text: obj.data( 'uploader-button-text' ),
			},
			multiple: mul
		} );

	}

  function hppport_checkRemoveAll() {

    if ( $( '#hppport-gallery-metabox-list li' ).length > 0 ) {
      hppport_showRemoveAll();
    } else {
      hppport_hideRemoveAll();
    }

  }

  function hppport_showRemoveAll() {
    $( '#hppport-gallery-metabox a.hppport-button-remove-all' ).css( 'visibility', 'visible' );
  }

  function hppport_hideRemoveAll() {
    $( '#hppport-gallery-metabox a.hppport-button-remove-all' ).css( 'visibility', 'hidden' );
  }

  function hppport_resetIndex() {

    $( '#hppport-gallery-metabox-list li' ).each( function( i ) {
      $( this ).find( 'input:hidden' ).attr( 'name', 'hppport_gallery_id[' + i + ']' );
    } );

  }

  function hppport_makeSortable() {

    $( '#hppport-gallery-metabox-list' ).sortable( {
      opacity: 1,
      stop: function() {
        hppport_resetIndex();
      }
    } );

  }

  // Launch
  hppport_checkRemoveAll();
  hppport_makeSortable();

  /* END */

} );
